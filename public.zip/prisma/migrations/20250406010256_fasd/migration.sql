-- CreateTable
CREATE TABLE "refs" (
    "id" SERIAL NOT NULL,
    "address" TEXT,
    "refAdr" TEXT,

    CONSTRAINT "refs_pkey" PRIMARY KEY ("id")
);
